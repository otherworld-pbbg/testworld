<?
include_once $privateRoot . "/class_player.inc.php";
include_once $privateRoot . "/class_character.inc.php";
include_once $privateRoot . "/class_time.inc.php";
include_once $privateRoot . "/class_global_map.inc.php";
//the part that checks if you're logged in
if (!isset($_POST["userid"])) {
		header('Location: index.php?page=login');
}

$user = '';
$pass = '';

$currentUser = $mysqli->real_escape_string($_POST['userid']);
$res = $mysqli->query("SELECT username, passhash FROM users WHERE uid='$currentUser' LIMIT 1");
if (!$res) {
    para("Unknown userid.");
    exit;
}
else if ($res->num_rows == 1) {
	$row = $res->fetch_object();
	$user = $row->username;
	$pass = $row->passhash;
}


if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    
    if (($_COOKIE['username'] != $user) || ($_COOKIE['password'] != $pass)) {    
        header('Location: index.php?page=login');
    } else {
        ptag ("p", "(Logged in as " . $_COOKIE['username'] . ".)", "class='right'");
    }
    
} else {
    header('Location: index.php?page=login');//if you're not authenticated then you get the boot
}
//end logged in check
//Next check if character selected
if (!isset($_POST["charid"])) {
		header('Location: index.php?page=charlist&userid=' . $currentUser);
}
else {
	//check if the player is allowed to view this character
	$charcheck = $mysqli->real_escape_string($_POST['charid']);
	$curChar = new Character($mysqli, $charcheck);
	$watcherRole = $curChar->checkPermission($currentUser);
	
	if ($watcherRole>1) para("You shouldn't be here since you're a watcher.");
	else if ($watcherRole<1) header('Location: index.php?page=charlist&userid=' . $u);
	else {
		//user is authorized to view this character
		$bodyId = $curChar->getBasicData();
		if ($bodyId == -1) echo "This character doesn't have a body so it cannot be played.";
		else {
			if (!isset($_POST['sel2'])||!isset($_POST['sel3'])||!isset($_POST['targetid'])) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=4');
			else if (!is_numeric($_POST['sel2'])||!is_numeric($_POST['sel3'])||!is_numeric($_POST['targetid'])) para("Error: Something is not numeric.");
			else {
				if ($_POST['sel2']==1) {
					if (!isset($_POST['grams'])) para("Error: Amount is not set.");
					else if (!is_numeric($_POST['grams'])) para("Error: Amount is not numeric.");
					else if ($_POST['grams']==0) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=4');
					else {
						$res1 = $curChar->storeGroundObject($_POST['targetid'], $_POST['sel3'], "weight", $_POST['grams']);
						if ($res1) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=4');
						else para("Could not store. Possible reasons: the item you're about to store isn't in the same location, the container is in another location, the container is too full.");
					}
				}
				else if ($_POST['sel2']==2) {
					if (!isset($_POST['pieces'])) para("Error: Amount is not set.");
					else if (!is_numeric($_POST['pieces'])) para("Error: Amount is not numeric.");
					else if ($_POST['pieces']==0) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=4');
					else {
						$res2 = $curChar->storeGroundObject($_POST['targetid'], $_POST['sel3'], "pieces", $_POST['pieces']);
						if ($res2) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=4');
						else para("Could not store. Possible reasons: the item you're about to store isn't in the same location, the container is in another location, the container is too full, you're trying to store multiples of an object that doesn't stack.");
					}
				}
				else if ($_POST['sel2']==3) {
					$res3 = $curChar->storeGroundObject($_POST['targetid'], $_POST['sel3'], "whole");
					if ($res3) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=4');
					else para("Could not store. Possible reasons: the item you're about to store isn't in the same location, the container is in another location, the container is too full.");
				}
			}
		}
	}
}
?>
