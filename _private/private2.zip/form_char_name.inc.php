<?
include_once $privateRoot . "/class_player.inc.php";
include_once $privateRoot . "/class_character.inc.php";

//the part that checks if you're logged in
if (!isset($_GET["userid"])) {
		header('Location: index.php?page=login');
}

$user = '';
$pass = '';

$currentUser = $mysqli->real_escape_string($_GET['userid']);
$res = $mysqli->query("SELECT username, passhash FROM users WHERE uid='$currentUser' LIMIT 1");
if (!$res) {
    para("Unknown userid.");
    exit;
}
else if ($res->num_rows == 1) {
	$row = $res->fetch_object();
	$user = $row->username;
	$pass = $row->passhash;
}


if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    
    if (($_COOKIE['username'] != $user) || ($_COOKIE['password'] != $pass)) {    
        header('Location: index.php?page=login');
    } else {
        ptag ("p", "(Logged in as " . $_COOKIE['username'] . ".)", "class='right'");
    }
    
} else {
    header('Location: index.php?page=login');//if you're not authenticated then you get the boot
}
//end logged in check
//Next check if character selected
if (!isset($_GET["charid"])) {
		header('Location: index.php?page=charlist&userid=' . $currentUser);
}
else {
	//check if the player is allowed to view this character
	$charcheck = $mysqli->real_escape_string($_GET['charid']);
	$curChar = new Character($mysqli, $charcheck);
	$watcherRole = $curChar->checkPermission($currentUser);
	
	if ($watcherRole>1) ptag("p", "Disclaimer: You are a watcher, so you can't carry out actions. You only see what the character sees.");
	
	if ($watcherRole<1) header('Location: index.php?page=charlist&userid=' . $u);
	else {
		//user is authorized to view this character
		$bodyId = $curChar->getBasicData();
		if ($bodyId == -1) echo "This character doesn't have a body so it cannot be played.";
		else {
			if (!isset($_GET['ocharid'])) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=5');
			else if (!is_numeric($_GET['ocharid'])) {
				header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=5');
			}
			else {
				$ochar = new Character($mysqli, $_GET['ocharid']);
				$ochar->getBasicData();
				echo "<div class='bar'>\n";
				echo "<div class='left_header'>\n";
				ptag("h4", "Current character:");
				para($curChar->cname);
				echo "</div></div>";
				$oname = $curChar->getKnownAs($ochar->bodyId);
				echo "<div class='bar'>\n";
				ptag("h1", "Rename person");
				echo "<form action='index.php?page=changeCharName' method='post' class='narrow'>";
				para("Current name: " . $oname);
				para("Description: " . $ochar->getAgeSex());
				echo "<p>";
				ptag("label", "New name: ", "for='nametext'");
				ptag("input", "", "type='text' length='50' maxlength='50' name='nametext' id='nametext' value='" . $oname . "'");
				ptag("input" , "", "type='hidden' name='charid' value='$charcheck'");
				ptag("input" , "", "type='hidden' name='ocharid' value='" . $_GET['ocharid'] . "'");
				ptag("input" , "", "type='hidden' name='userid' value='$currentUser'");
				echo "</p>";
				echo "<p class='right'>";
				ptag("input", "", "type='submit' value='Change'");
				echo "</p>";
				echo "</form>";
				echo "</div>";
			}
		}
	}
}
?>
