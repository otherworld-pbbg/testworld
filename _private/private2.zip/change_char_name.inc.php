<?
include_once $privateRoot . "/class_player.inc.php";
include_once $privateRoot . "/class_character.inc.php";

//the part that checks if you're logged in
if (!isset($_POST["userid"])) {
		header('Location: index.php?page=login');
}

$user = '';
$pass = '';

$currentUser = $mysqli->real_escape_string($_POST['userid']);
$res = $mysqli->query("SELECT username, passhash FROM users WHERE uid='$currentUser' LIMIT 1");
if (!$res) {
    para("Unknown userid.");
    exit;
}
else if ($res->num_rows == 1) {
	$row = $res->fetch_object();
	$user = $row->username;
	$pass = $row->passhash;
}


if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    
    if (($_COOKIE['username'] != $user) || ($_COOKIE['password'] != $pass)) {    
        header('Location: index.php?page=login');
    } else {
        ptag ("p", "(Logged in as " . $_COOKIE['username'] . ".)", "class='right'");
    }
    
} else {
    header('Location: index.php?page=login');//if you're not authenticated then you get the boot
}
//end logged in check
//Next check if character selected
if (!isset($_POST["charid"])) {
		header('Location: index.php?page=charlist&userid=' . $currentUser);
}
else {
	//check if the player is allowed to view this character
	$charcheck = $mysqli->real_escape_string($_POST['charid']);
	$curChar = new Character($mysqli, $charcheck);
	$watcherRole = $curChar->checkPermission($currentUser);
	
	if ($watcherRole>1) {
		para("You cannot change names on someone else's behalf when you're a watcher.");
	}
	else {
		if ($watcherRole<1) header('Location: index.php?page=charlist&userid=' . $u);
		else {
			//user is authorized to view this character
			$bodyId = $curChar->getBasicData();
			if ($bodyId == -1) echo "This character doesn't have a body so it cannot be played.";
			else {
				if (!isset($_POST['ocharid'])||!isset($_POST['nametext'])) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=5');
				else if (!is_numeric($_POST['ocharid'])) {
					header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=5');
				}
				else {
					$ochar = new Character($mysqli, $_POST['ocharid']);
					$oBodyId = $ochar->getBasicData();
					if ($oBodyId == -1) para("It appears you're trying to name someone incorporeal.");
					else {
						$name = $mysqli->real_escape_string($_POST['nametext']);
						$curChar->nameObject($oBodyId, $name);
						header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=5');
					}
				}
			}
		}
	}
}
?>
