<?
//this needs the following post variables: direction, charid, userid

include_once $privateRoot . "/class_player.inc.php";
include_once $privateRoot . "/class_character.inc.php";
include_once $privateRoot . "/class_time.inc.php";
include_once $privateRoot . "/class_global_map.inc.php";

//the part that checks if you're logged in
if (!isset($_POST["userid"])) {
		header('Location: index.php?page=login');
}

$user = '';
$pass = '';

$currentUser = $mysqli->real_escape_string($_POST['userid']);
$res = $mysqli->query("SELECT username, passhash FROM users WHERE uid='$currentUser' LIMIT 1");
if (!$res) {
    para("Query failed.");
    exit;
}
else if ($res->num_rows == 1) {
	$row = $res->fetch_object();
	$user = $row->username;
	$pass = $row->passhash;
}

if (isset($_COOKIE['username']) && isset($_COOKIE['password'])) {
    
    if (($_COOKIE['username'] != $user) || ($_COOKIE['password'] != $pass)) {    
        header('Location: index.php?page=login');
    } else {
        ptag ("p", "(Logged in as " . $_COOKIE['username'] . ".)", "class='right'");
    }
    
} else {
    header('Location: index.php?page=login');//if you're not authenticated then you get the boot
}
//end logged in check
//Next check if character selected
if (!isset($_POST["charid"])) {
		header('Location: index.php?page=charlist&userid=' . $currentUser);
}
else {
	//check if the player is allowed to view this character
	$charcheck = $mysqli->real_escape_string($_POST['charid']);
	$curChar = new Character($mysqli, $charcheck);
	$watcherRole = $curChar->checkPermission($currentUser);
	
	if ($watcherRole<1) header('Location: index.php?page=charlist&userid=' . $currentUser);
	else {
		//user is authorized to view this character
		$bodyId = $curChar->getBasicData();
		if ($bodyId == -1) echo "This character doesn't have a body so it cannot be played.";
		else {			
			if ($watcherRole>1) {
				para("You cannot move on someone else's behalf when you're a watcher.");
			}
			else {
				if (!isset($_POST["sel3"])) {
					header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=3');
				}
				else if (!is_numeric($_POST["sel3"])) header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=3');
				else {
					$target = new Obj($mysqli, $_POST["sel3"]);
					$target->getBasicData();
					if ($target->x!=$curChar->x||$target->y!=$curChar->y) para("You're trying to jump to another location without using AP. Naughty naughty.");
					else {
						$check = $curChar->moveLocal($target->localx, $target->localy);
						if ($check==-1) echo "Failed to move for some reason. Maybe you were trying to move into a square in which you already were.";
						else header('Location: index.php?page=viewchar&charid=' . $charcheck . '&userid=' . $currentUser . '&tab=3');
					}
				}
				
			}
		}
	}
}
?>
